#include <stdio.h>

int main(void)
{

  // TODO c)
	return 0;
}
