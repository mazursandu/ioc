#include <stdio.h>

int main(void)
{
	// TODO: b)

  // TODO: c)
	
	return 0;
}
