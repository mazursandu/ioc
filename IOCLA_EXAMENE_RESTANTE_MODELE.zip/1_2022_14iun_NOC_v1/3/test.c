#include <stdio.h>

int main(void)
{

  // TODO c)
  starship("abc TREB","TREB");
	return 0;
}
