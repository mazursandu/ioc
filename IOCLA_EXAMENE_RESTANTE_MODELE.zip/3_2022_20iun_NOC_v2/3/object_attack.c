#include <stdio.h>

int main () {
    /* call hidden function from object.o with the "key1 key2" argument */

    return 0;
}
