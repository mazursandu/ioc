#include <stdio.h>

int main(void)
{
	// TODO: b)
	reveal_passwd("heard");

  // TODO: c)
	show_message(19228, "yorkshire terrier");
	
	return 0;
}
